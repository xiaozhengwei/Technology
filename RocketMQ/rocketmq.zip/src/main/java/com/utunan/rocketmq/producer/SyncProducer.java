package com.utunan.rocketmq.producer;

public class SyncProducer {
}
