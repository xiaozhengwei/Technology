# kafka_book_demo
《深入理解Kafka：核心设计与实践原理》书籍中的代码示例。

代码清单已经更新完毕，如有疑问可以提issue.

-----
欢迎支持笔者新作：《深入理解Kafka:核心设计与实践原理》和《RabbitMQ实战指南》，同时欢迎关注笔者的微信公众号：朱小厮的博客。
![](https://img-blog.csdnimg.cn/20190221231530525.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTMyNTY4MTY=,size_16,color_FFFFFF,t_70)
